#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if ! command -v python >/dev/null 2>&1; then
    echo "No está instalado Python."
    echo "Ejecuta: ./instalar_cachyos.sh"
    exit 1
fi

if ! python -c "import flask" >/dev/null 2>&1; then
    echo "No está instalado Flask."
    echo "Ejecuta: ./instalar_cachyos.sh"
    exit 1
fi

exec python app.py
