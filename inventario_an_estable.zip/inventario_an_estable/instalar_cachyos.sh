#!/usr/bin/env bash
set -e
echo "Instalando Python y Flask desde los repositorios de CachyOS..."
sudo pacman -S --needed python python-flask
echo
echo "Instalación terminada."
echo "Ahora ejecuta: ./iniciar.sh"
