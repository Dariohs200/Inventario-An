# Inventario AN — versión estable

Esta versión no incluye códigos QR. Usa solamente Python, Flask y SQLite.

## Instalar en CachyOS

Abre una terminal dentro de esta carpeta y ejecuta:

```bash
chmod +x instalar_cachyos.sh iniciar.sh
./instalar_cachyos.sh
./iniciar.sh
```

También puedes iniciarlo manualmente:

```bash
python app.py
```

## Abrir en la computadora

```text
http://127.0.0.1:5000
```

## Abrir en el celular

Al ejecutar `./iniciar.sh`, la terminal mostrará una dirección parecida a:

```text
http://192.168.1.35:5000
```

Escribe esa dirección completa en el navegador del celular.

Requisitos:

- Computadora y celular conectados al mismo Wi-Fi.
- Mantener abierta la terminal.
- No usar `127.0.0.1` en el celular.
- Desactivar temporalmente los datos móviles si el celular intenta cambiar de red.

## Usuarios iniciales

- Administrador: `admin` / `1234`
- Vendedor 1: `venta1` / `1234`
- Vendedor 2: `venta2` / `1234`

## Reiniciar el inventario

Detén el programa con `Ctrl+C` y ejecuta:

```bash
rm inventario.db inventario.db-shm inventario.db-wal 2>/dev/null
./iniciar.sh
```

## Copia de seguridad

Detén el programa y copia `inventario.db` a otra carpeta o memoria.
