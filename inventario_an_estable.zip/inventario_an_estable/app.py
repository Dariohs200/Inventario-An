from __future__ import annotations

import os
import socket
import sqlite3
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "inventario.db"

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("INVENTARIO_SECRET_KEY", "inventario-an-local"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)


def get_db() -> sqlite3.Connection:
    connection = sqlite3.connect(DATABASE, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


def init_db() -> None:
    connection = get_db()
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            usuario TEXT NOT NULL UNIQUE,
            clave_hash TEXT NOT NULL,
            rol TEXT NOT NULL CHECK (rol IN ('admin', 'vendedor')),
            activo INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            categoria TEXT NOT NULL DEFAULT '',
            unidad TEXT NOT NULL,
            stock REAL NOT NULL DEFAULT 0 CHECK (stock >= 0),
            stock_minimo REAL NOT NULL DEFAULT 0 CHECK (stock_minimo >= 0),
            costo REAL NOT NULL DEFAULT 0 CHECK (costo >= 0),
            precio REAL NOT NULL DEFAULT 0 CHECK (precio >= 0),
            activo INTEGER NOT NULL DEFAULT 1,
            creado_en TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS ventas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            usuario_id INTEGER NOT NULL,
            total REAL NOT NULL CHECK (total >= 0),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );

        CREATE TABLE IF NOT EXISTS venta_detalles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venta_id INTEGER NOT NULL,
            producto_id INTEGER NOT NULL,
            cantidad REAL NOT NULL CHECK (cantidad > 0),
            precio_unitario REAL NOT NULL CHECK (precio_unitario >= 0),
            subtotal REAL NOT NULL CHECK (subtotal >= 0),
            FOREIGN KEY (venta_id) REFERENCES ventas(id),
            FOREIGN KEY (producto_id) REFERENCES productos(id)
        );

        CREATE TABLE IF NOT EXISTS movimientos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            producto_id INTEGER NOT NULL,
            usuario_id INTEGER NOT NULL,
            fecha TEXT NOT NULL,
            tipo TEXT NOT NULL CHECK (tipo IN ('entrada', 'venta', 'ajuste')),
            cantidad REAL NOT NULL,
            nota TEXT NOT NULL DEFAULT '',
            FOREIGN KEY (producto_id) REFERENCES productos(id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );
        """
    )

    total_users = connection.execute(
        "SELECT COUNT(*) AS total FROM usuarios"
    ).fetchone()["total"]

    if total_users == 0:
        connection.executemany(
            """
            INSERT INTO usuarios (nombre, usuario, clave_hash, rol)
            VALUES (?, ?, ?, ?)
            """,
            [
                ("Darío", "admin", generate_password_hash("1234"), "admin"),
                ("Vendedor 1", "venta1", generate_password_hash("1234"), "vendedor"),
                ("Vendedor 2", "venta2", generate_password_hash("1234"), "vendedor"),
            ],
        )

    connection.commit()
    connection.close()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "usuario_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "usuario_id" not in session:
            return redirect(url_for("login"))
        if session.get("rol") != "admin":
            flash("Esta opción es exclusiva del administrador.", "error")
            return redirect(url_for("inicio"))
        return view(*args, **kwargs)

    return wrapped


@app.template_filter("dinero")
def dinero(value: float) -> str:
    return f"${float(value):,.2f}"


@app.template_filter("numero")
def numero(value: float) -> str:
    number = float(value)
    return f"{int(number):,}" if number.is_integer() else f"{number:,.2f}"


@app.route("/login", methods=["GET", "POST"])
def login():
    if "usuario_id" in session:
        return redirect(url_for("inicio"))

    if request.method == "POST":
        username = request.form.get("usuario", "").strip()
        password = request.form.get("clave", "")

        connection = get_db()
        user = connection.execute(
            """
            SELECT * FROM usuarios
            WHERE usuario = ? AND activo = 1
            """,
            (username,),
        ).fetchone()
        connection.close()

        if user and check_password_hash(user["clave_hash"], password):
            session.clear()
            session["usuario_id"] = user["id"]
            session["nombre"] = user["nombre"]
            session["rol"] = user["rol"]
            return redirect(url_for("inicio"))

        flash("Usuario o contraseña incorrectos.", "error")

    return render_template("login.html")


@app.route("/salir")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def inicio():
    connection = get_db()

    summary = connection.execute(
        """
        SELECT
            COUNT(*) AS productos,
            COALESCE(SUM(stock * costo), 0) AS valor_inventario,
            COALESCE(SUM(CASE WHEN stock <= stock_minimo THEN 1 ELSE 0 END), 0)
                AS bajo_stock
        FROM productos
        WHERE activo = 1
        """
    ).fetchone()

    today = connection.execute(
        """
        SELECT
            COUNT(*) AS operaciones,
            COALESCE(SUM(total), 0) AS total
        FROM ventas
        WHERE DATE(fecha) = DATE('now', 'localtime')
        """
    ).fetchone()

    latest_sales = connection.execute(
        """
        SELECT v.id, v.fecha, v.total, u.nombre AS vendedor
        FROM ventas AS v
        JOIN usuarios AS u ON u.id = v.usuario_id
        ORDER BY v.id DESC
        LIMIT 8
        """
    ).fetchall()

    low_stock = connection.execute(
        """
        SELECT *
        FROM productos
        WHERE activo = 1 AND stock <= stock_minimo
        ORDER BY stock, nombre
        LIMIT 8
        """
    ).fetchall()

    connection.close()
    return render_template(
        "inicio.html",
        resumen=summary,
        hoy=today,
        ventas=latest_sales,
        bajos=low_stock,
    )


@app.route("/productos")
@login_required
def productos():
    query = request.args.get("q", "").strip()
    connection = get_db()

    if query:
        rows = connection.execute(
            """
            SELECT *
            FROM productos
            WHERE activo = 1
              AND (nombre LIKE ? OR categoria LIKE ?)
            ORDER BY nombre
            """,
            (f"%{query}%", f"%{query}%"),
        ).fetchall()
    else:
        rows = connection.execute(
            """
            SELECT *
            FROM productos
            WHERE activo = 1
            ORDER BY nombre
            """
        ).fetchall()

    connection.close()
    return render_template("productos.html", productos=rows, query=query)


@app.route("/productos/nuevo", methods=["GET", "POST"])
@admin_required
def producto_nuevo():
    if request.method == "POST":
        try:
            name = request.form.get("nombre", "").strip()
            category = request.form.get("categoria", "").strip()
            unit = request.form.get("unidad", "").strip()
            stock = float(request.form.get("stock", 0))
            minimum = float(request.form.get("stock_minimo", 0))
            cost = float(request.form.get("costo", 0))
            price = float(request.form.get("precio", 0))

            if not name or not unit:
                raise ValueError("El nombre y la unidad son obligatorios.")
            if min(stock, minimum, cost, price) < 0:
                raise ValueError("Los valores no pueden ser negativos.")

            now = datetime.now().isoformat(timespec="seconds")
            connection = get_db()
            cursor = connection.execute(
                """
                INSERT INTO productos
                    (nombre, categoria, unidad, stock, stock_minimo,
                     costo, precio, creado_en)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (name, category, unit, stock, minimum, cost, price, now),
            )

            if stock > 0:
                connection.execute(
                    """
                    INSERT INTO movimientos
                        (producto_id, usuario_id, fecha, tipo, cantidad, nota)
                    VALUES (?, ?, ?, 'entrada', ?, 'Inventario inicial')
                    """,
                    (cursor.lastrowid, session["usuario_id"], now, stock),
                )

            connection.commit()
            connection.close()
            flash("Producto guardado.", "ok")
            return redirect(url_for("productos"))

        except (ValueError, TypeError) as error:
            flash(str(error), "error")

    return render_template("producto_form.html")


@app.route("/productos/<int:product_id>/entrada", methods=["POST"])
@admin_required
def producto_entrada(product_id: int):
    try:
        quantity = float(request.form.get("cantidad", 0))
        note = request.form.get("nota", "").strip() or "Entrada de mercancía"
        if quantity <= 0:
            raise ValueError("La cantidad debe ser mayor que cero.")

        connection = get_db()
        product = connection.execute(
            "SELECT * FROM productos WHERE id = ? AND activo = 1",
            (product_id,),
        ).fetchone()

        if product is None:
            connection.close()
            raise ValueError("Producto no encontrado.")

        now = datetime.now().isoformat(timespec="seconds")
        connection.execute(
            "UPDATE productos SET stock = stock + ? WHERE id = ?",
            (quantity, product_id),
        )
        connection.execute(
            """
            INSERT INTO movimientos
                (producto_id, usuario_id, fecha, tipo, cantidad, nota)
            VALUES (?, ?, ?, 'entrada', ?, ?)
            """,
            (product_id, session["usuario_id"], now, quantity, note),
        )
        connection.commit()
        connection.close()
        flash("Entrada registrada.", "ok")

    except (ValueError, TypeError) as error:
        flash(str(error), "error")

    return redirect(url_for("productos"))


@app.route("/productos/<int:product_id>/ajuste", methods=["POST"])
@admin_required
def producto_ajuste(product_id: int):
    try:
        new_stock = float(request.form.get("nuevo_stock", 0))
        note = request.form.get("nota", "").strip() or "Conteo físico"

        if new_stock < 0:
            raise ValueError("El stock no puede ser negativo.")

        connection = get_db()
        product = connection.execute(
            "SELECT * FROM productos WHERE id = ? AND activo = 1",
            (product_id,),
        ).fetchone()

        if product is None:
            connection.close()
            raise ValueError("Producto no encontrado.")

        difference = new_stock - float(product["stock"])
        now = datetime.now().isoformat(timespec="seconds")
        connection.execute(
            "UPDATE productos SET stock = ? WHERE id = ?",
            (new_stock, product_id),
        )
        connection.execute(
            """
            INSERT INTO movimientos
                (producto_id, usuario_id, fecha, tipo, cantidad, nota)
            VALUES (?, ?, ?, 'ajuste', ?, ?)
            """,
            (product_id, session["usuario_id"], now, difference, note),
        )
        connection.commit()
        connection.close()
        flash("Stock ajustado.", "ok")

    except (ValueError, TypeError) as error:
        flash(str(error), "error")

    return redirect(url_for("productos"))


@app.route("/venta", methods=["GET", "POST"])
@login_required
def venta():
    connection = get_db()

    if request.method == "POST":
        ids = request.form.getlist("producto_id")
        quantities = request.form.getlist("cantidad")

        try:
            consolidated: dict[int, float] = {}

            for product_id_text, quantity_text in zip(ids, quantities):
                if not product_id_text or not quantity_text:
                    continue

                product_id = int(product_id_text)
                quantity = float(quantity_text)

                if quantity <= 0:
                    raise ValueError("Las cantidades deben ser mayores que cero.")

                consolidated[product_id] = (
                    consolidated.get(product_id, 0) + quantity
                )

            if not consolidated:
                raise ValueError("Agrega al menos un producto.")

            connection.execute("BEGIN IMMEDIATE")
            details = []
            total = 0.0

            for product_id, quantity in consolidated.items():
                product = connection.execute(
                    """
                    SELECT *
                    FROM productos
                    WHERE id = ? AND activo = 1
                    """,
                    (product_id,),
                ).fetchone()

                if product is None:
                    raise ValueError("Uno de los productos ya no existe.")

                if quantity > float(product["stock"]):
                    raise ValueError(
                        f"Stock insuficiente de {product['nombre']}. "
                        f"Disponible: {float(product['stock']):g} "
                        f"{product['unidad']}."
                    )

                subtotal = round(quantity * float(product["precio"]), 2)
                total += subtotal
                details.append((product, quantity, subtotal))

            total = round(total, 2)
            now = datetime.now().isoformat(timespec="seconds")
            sale_cursor = connection.execute(
                """
                INSERT INTO ventas (fecha, usuario_id, total)
                VALUES (?, ?, ?)
                """,
                (now, session["usuario_id"], total),
            )
            sale_id = sale_cursor.lastrowid

            for product, quantity, subtotal in details:
                connection.execute(
                    """
                    INSERT INTO venta_detalles
                        (venta_id, producto_id, cantidad,
                         precio_unitario, subtotal)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        sale_id,
                        product["id"],
                        quantity,
                        product["precio"],
                        subtotal,
                    ),
                )
                connection.execute(
                    """
                    UPDATE productos
                    SET stock = stock - ?
                    WHERE id = ?
                    """,
                    (quantity, product["id"]),
                )
                connection.execute(
                    """
                    INSERT INTO movimientos
                        (producto_id, usuario_id, fecha,
                         tipo, cantidad, nota)
                    VALUES (?, ?, ?, 'venta', ?, ?)
                    """,
                    (
                        product["id"],
                        session["usuario_id"],
                        now,
                        -quantity,
                        f"Venta #{sale_id}",
                    ),
                )

            connection.commit()
            connection.close()
            return redirect(url_for("ticket", sale_id=sale_id))

        except (ValueError, TypeError) as error:
            connection.rollback()
            flash(str(error), "error")

    products = connection.execute(
        """
        SELECT *
        FROM productos
        WHERE activo = 1 AND stock > 0
        ORDER BY nombre
        """
    ).fetchall()
    connection.close()
    return render_template("venta.html", productos=products)


@app.route("/ticket/<int:sale_id>")
@login_required
def ticket(sale_id: int):
    connection = get_db()
    sale = connection.execute(
        """
        SELECT v.*, u.nombre AS vendedor
        FROM ventas AS v
        JOIN usuarios AS u ON u.id = v.usuario_id
        WHERE v.id = ?
        """,
        (sale_id,),
    ).fetchone()

    details = connection.execute(
        """
        SELECT vd.*, p.nombre, p.unidad
        FROM venta_detalles AS vd
        JOIN productos AS p ON p.id = vd.producto_id
        WHERE vd.venta_id = ?
        ORDER BY vd.id
        """,
        (sale_id,),
    ).fetchall()
    connection.close()

    if sale is None:
        flash("Venta no encontrada.", "error")
        return redirect(url_for("inicio"))

    return render_template("ticket.html", venta=sale, detalles=details)


@app.route("/movimientos")
@admin_required
def movimientos():
    connection = get_db()
    rows = connection.execute(
        """
        SELECT
            m.*, p.nombre AS producto, p.unidad, u.nombre AS usuario
        FROM movimientos AS m
        JOIN productos AS p ON p.id = m.producto_id
        JOIN usuarios AS u ON u.id = m.usuario_id
        ORDER BY m.id DESC
        LIMIT 300
        """
    ).fetchall()
    connection.close()
    return render_template("movimientos.html", movimientos=rows)


@app.route("/estado")
def estado():
    return {"estado": "correcto", "aplicacion": "Inventario AN"}


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("1.1.1.1", 80))
        return sock.getsockname()[0]
    except OSError:
        return "IP-DE-LA-COMPUTADORA"
    finally:
        sock.close()


if __name__ == "__main__":
    init_db()
    ip = local_ip()
    print()
    print("=" * 58)
    print(" INVENTARIO AN")
    print(" Computadora: http://127.0.0.1:5000")
    print(f" Celular:     http://{ip}:5000")
    print(" Deja esta terminal abierta mientras uses el programa.")
    print("=" * 58)
    print()
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
